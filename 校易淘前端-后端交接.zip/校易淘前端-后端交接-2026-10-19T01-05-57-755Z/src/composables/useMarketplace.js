import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { categories, products as initialProducts, schools } from '../data/products'
import { readStorage, writeStorage } from '../utils/storage'

// 当前为本地演示状态。接入真实 API 前，按 docs/接口对接说明.md 替换数据来源。
// 此处的昵称、金额和 localStorage 均不能作为服务端认证或定价依据。
export function useMarketplace() {
const storedProducts = readStorage('ct.products', [])
const customProducts = ref(Array.isArray(storedProducts) ? storedProducts.filter(p => p && typeof p.id === 'string' && typeof p.title === 'string' && Number.isFinite(p.price) && p.price > 0 && categories.some(c => c.id !== 'all' && c.id === p.category)) : [])
const allProducts = computed(() => [...customProducts.value, ...initialProducts])
const storedCart = readStorage('ct.cart', [])
const cart = ref(Array.isArray(storedCart) ? storedCart.filter(x => x && typeof x.id === 'string').map(x => ({ id: x.id, quantity: 1, selected: x.selected !== false })) : [])
const storedFavorites = readStorage('ct.favorites', [])
const favorites = ref(Array.isArray(storedFavorites) ? storedFavorites.filter(x => typeof x === 'string') : [])
const savedUser = readStorage('ct.user', null)
const user = ref(savedUser && typeof savedUser.name === 'string' ? { name: savedUser.name } : null)
const storedOrders = readStorage('ct.orders', [])
const orders = ref(Array.isArray(storedOrders) ? storedOrders.filter(o => o && typeof o.no === 'string' && Array.isArray(o.items) && Number.isFinite(o.total)) : [])
const page = ref(['home', 'favorites', 'cart', 'profile'].includes(location.hash.slice(1)) ? location.hash.slice(1) : 'home')
const keyword = ref('')
const category = ref('all')
const school = ref('全部学校')
const condition = ref('全部成色')
const sort = ref('recommended')
const detail = ref(null)
const detailOpen = computed({ get: () => Boolean(detail.value), set: value => { if (!value) detail.value = null } })
const loginOpen = ref(false)
const publishOpen = ref(false)
const checkoutOpen = ref(false)
const loginName = ref('')
const agreed = ref(false)
const address = ref('')
const receiver = ref('')
const contact = ref('')
const publish = ref({ title: '', category: 'books', price: '', condition: '九成新', location: '', description: '' })
let storageWarned = false

function persist(key, value) {
  if (!writeStorage(key, value) && !storageWarned) {
    storageWarned = true
    ElMessage.warning('浏览器存储不可用，本次操作仅保留在当前页面')
  }
}
watch(cart, v => persist('ct.cart', v), { deep: true })
watch(favorites, v => persist('ct.favorites', v), { deep: true })
watch(user, v => persist('ct.user', v))
watch(orders, v => persist('ct.orders', v), { deep: true })
watch(customProducts, v => persist('ct.products', v), { deep: true })
watch(page, value => { location.hash = value; window.scrollTo({ top: 0, behavior: 'smooth' }) })
function syncHash() {
  const target = location.hash.slice(1)
  page.value = ['home', 'favorites', 'cart', 'profile'].includes(target) ? target : 'home'
}
onMounted(() => window.addEventListener('hashchange', syncHash))
onUnmounted(() => window.removeEventListener('hashchange', syncHash))

const filtered = computed(() => {
  let result = allProducts.value.filter(p =>
    (page.value !== 'favorites' || favorites.value.includes(p.id)) &&
    (category.value === 'all' || p.category === category.value) &&
    (!keyword.value.trim() || [p.title, p.description, p.seller].some(v => (v || '').toLowerCase().includes(keyword.value.trim().toLowerCase()))) &&
    (school.value === '全部学校' || p.school === school.value) &&
    (condition.value === '全部成色' || p.condition === condition.value))
  if (sort.value === 'priceAsc') result = [...result].sort((a, b) => a.price - b.price)
  if (sort.value === 'priceDesc') result = [...result].sort((a, b) => b.price - a.price)
  if (sort.value === 'newest') result = [...result].sort((a, b) => a.time - b.time)
  return result
})
const cartProducts = computed(() => cart.value.map(item => ({ ...item, product: allProducts.value.find(p => p.id === item.id) })).filter(x => x.product))
const selectedItems = computed(() => cartProducts.value.filter(x => x.selected))
const total = computed(() => selectedItems.value.reduce((sum, item) => sum + Math.round(item.product.price * 100), 0) / 100)
const allSelected = computed(() => cartProducts.value.length > 0 && cartProducts.value.every(x => x.selected))
const myProducts = computed(() => customProducts.value.filter(p => p.seller === user.value?.name))

function money(amount) { return Number(amount).toFixed(2) }
function notify(message) { ElMessage.success(message) }
function requireUser() {
  if (user.value) return true
  loginOpen.value = true
  ElMessage.info('请先设置演示身份')
  return false
}
function toggleFavorite(id) {
  favorites.value = favorites.value.includes(id) ? favorites.value.filter(x => x !== id) : [...favorites.value, id]
}
function addCart(product) {
  if (product.isMine && product.seller === user.value?.name) return ElMessage.info('不能购买自己发布的商品')
  if (cart.value.some(x => x.id === product.id)) return ElMessage.info('这件好物已经在购物车里了')
  cart.value.push({ id: product.id, quantity: 1, selected: true })
  notify('已加入购物车')
}
function removeCart(id) { cart.value = cart.value.filter(x => x.id !== id) }
function selectItem(id, checked) { const item = cart.value.find(x => x.id === id); if (item) item.selected = checked }
function toggleAll(checked) { cart.value.forEach(x => { x.selected = checked }) }
function resetFilters() { keyword.value = ''; category.value = 'all'; school.value = '全部学校'; condition.value = '全部成色'; sort.value = 'recommended' }
function navigate(target) { page.value = target; if (target === 'home' || target === 'favorites') resetFilters() }
function search(term) {
  keyword.value = term ?? keyword.value
  page.value = 'home'
  requestAnimationFrame(() => document.getElementById('market')?.scrollIntoView({ behavior: 'smooth' }))
}
function login() {
  const name = loginName.value.trim()
  if (name.length < 2 || name.length > 16) return ElMessage.warning('昵称需要 2～16 个字符')
  if (!agreed.value) return ElMessage.warning('请确认演示模式说明')
  user.value = { name }
  loginOpen.value = false
  notify('欢迎来到校易淘，' + name)
}
function logout() { user.value = null; notify('已退出演示身份') }
function openPublish() { if (requireUser()) publishOpen.value = true }
function submitPublish() {
  const p = publish.value
  const price = Number(p.price)
  if (p.title.trim().length < 4) return ElMessage.warning('商品标题至少填写 4 个字')
  if (!Number.isFinite(price) || price < 0.01 || price > 99999) return ElMessage.warning('请输入 0.01～99999 元之间的价格')
  if (!p.location.trim() || p.description.trim().length < 10) return ElMessage.warning('请填写交接地点与至少 10 个字的描述')
  if (!requireUser()) return
  customProducts.value.unshift({
    id: 'local-' + crypto.randomUUID(), title: p.title.trim(), price: Math.round(price * 100) / 100,
    category: p.category, condition: p.condition, location: p.location.trim(), description: p.description.trim(),
    school: '本校', seller: user.value.name, avatar: user.value.name.slice(0, 1), art: 'custom', color: '#e6ede3', time: 0, tag: '本地发布', isMine: true,
  })
  publishOpen.value = false
  publish.value = { title: '', category: 'books', price: '', condition: '九成新', location: '', description: '' }
  navigate('home')
  notify('已保存到本机演示列表，尚未提交平台审核')
}
function startCheckout() {
  if (!selectedItems.value.length) return ElMessage.warning('请先选择要结算的商品')
  if (!requireUser()) return
  checkoutOpen.value = true
}
async function submitOrder() {
  if (!requireUser()) return
  if (!receiver.value.trim() || !address.value.trim()) return ElMessage.warning('请填写收货人和收货地址')
  if (!/^1[3-9]\d{9}$/.test(contact.value)) return ElMessage.warning('请输入有效的 11 位手机号')
  if (!selectedItems.value.length) return ElMessage.warning('请先选择商品')
  try {
    await ElMessageBox.confirm('将创建本地演示订单，不会发起真实支付或配送。是否继续？', '确认演示订单', { confirmButtonText: '创建演示订单', cancelButtonText: '返回修改', type: 'info' })
  } catch { return }
  const picked = selectedItems.value.map(x => ({ ...x.product }))
  orders.value.unshift({ no: 'DEMO-' + Date.now(), items: picked, total: total.value, date: new Date().toLocaleString('zh-CN'), user: user.value.name, status: '演示完成' })
  const ids = new Set(picked.map(x => x.id))
  cart.value = cart.value.filter(x => !ids.has(x.id))
  checkoutOpen.value = false
  detail.value = null
  // 不持久化地址与手机号，演示结束即清空。
  receiver.value = ''; contact.value = ''; address.value = ''
  page.value = 'profile'
  notify('演示订单已创建，未发生扣款')
}

return { categories, schools, page, keyword, category, school, condition, sort, detail, detailOpen, loginOpen, publishOpen, checkoutOpen, loginName, agreed, address, receiver, contact, publish, user, favorites, orders, filtered, cartProducts, selectedItems, total, allSelected, myProducts, money, toggleFavorite, addCart, removeCart, selectItem, toggleAll, resetFilters, navigate, search, login, logout, openPublish, submitPublish, startCheckout, submitOrder }
}
