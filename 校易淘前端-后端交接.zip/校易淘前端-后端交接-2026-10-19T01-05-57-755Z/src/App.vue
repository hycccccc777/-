<script setup>
import Icon from './components/Icon.vue'
import ProductArt from './components/ProductArt.vue'
import { useMarketplace } from './composables/useMarketplace'
const { categories, schools, page, keyword, category, school, condition, sort, detail, detailOpen, loginOpen, publishOpen, checkoutOpen, loginName, agreed, address, receiver, contact, publish, user, favorites, orders, filtered, cartProducts, selectedItems, total, allSelected, myProducts, money, toggleFavorite, addCart, removeCart, selectItem, toggleAll, resetFilters, navigate, search, login, logout, openPublish, submitPublish, startCheckout, submitOrder } = useMarketplace()
</script>

<template>
  <div class="app-shell">
    <div class="topbar"><div class="container topbar-inner"><span><Icon name="leaf" :size="14" /> 让校园闲置，开启下一段故事</span><span class="topbar-right">校园好物循环计划 <span class="tiny-dot"></span> 本地交互演示版</span></div></div>
    <header class="header">
      <div class="container header-inner">
        <button class="brand" @click="navigate('home')" aria-label="校易淘首页"><span class="brand-mark">易<span>↗</span></span><span><strong>校易淘</strong><small>CAMPUS TRADE</small></span></button>
        <div class="campus"><Icon name="location" :size="16" /><span>校园联盟</span></div>
        <form class="search-form" @submit.prevent="search()"><Icon name="search" :size="19" /><input v-model="keyword" aria-label="搜索校园好物" placeholder="搜一搜，发现你需要的校园好物" maxlength="80"><button type="submit">搜索</button></form>
        <div class="header-actions">
          <button class="icon-button cart-button" @click="navigate('cart')" aria-label="打开购物车"><Icon name="cart" :size="23" /><span v-if="cartProducts.length" class="badge">{{ cartProducts.length }}</span></button>
          <button class="account-button" @click="user ? navigate('profile') : loginOpen = true"><span class="avatar small">{{ user ? user.name.slice(0, 1) : '同' }}</span><span>{{ user?.name || '登录 / 注册' }}</span></button>
        </div>
      </div>
      <div class="container nav-row"><nav aria-label="主导航"><button :class="{ active: page === 'home' }" @click="navigate('home')">发现好物</button><button :class="{ active: page === 'favorites' }" @click="navigate('favorites')">我的收藏<span v-if="favorites.length" class="nav-count">{{ favorites.length }}</span></button><button :class="{ active: page === 'cart' }" @click="navigate('cart')">购物车</button><button :class="{ active: page === 'profile' }" @click="navigate('profile')">个人中心</button></nav><button class="publish-button" @click="openPublish"><Icon name="plus" :size="17" /> 发布闲置</button></div>
    </header>

    <main class="container main-content">
      <template v-if="page === 'home' || page === 'favorites'">
        <section v-if="page === 'home'" class="hero">
          <div class="hero-copy"><div class="eyebrow"><span></span> 少一点闲置，多一点可能</div><h1>你的闲置，<br>是另一个人的<span>心动好物。</span></h1><p>从一本课本，到一辆单车。<br>让每一份喜欢，在校园里继续。</p><button class="primary-button" @click="openPublish">让闲置流动起来 <Icon name="arrow" :size="18" /></button><div class="hero-note"><span class="mini-avatars"><i>林</i><i>周</i><i>陈</i></span><span>和同学一起，开启循环生活</span></div></div>
          <div class="hero-art"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><span class="art-spark spark-one">✳</span><span class="art-spark spark-two">✧</span><div class="hero-book"><ProductArt type="math" background="#e6dfcd" /><span class="floating-price">好书不止读一次</span></div><div class="hero-headphones"><ProductArt type="headphones" background="#d4dfd2" /></div><div class="hero-bag"><ProductArt type="bag" background="#ece5d7" /></div><div class="hero-sticker"><Icon name="leaf" :size="24" /><span>GOOD THINGS<br>GO AROUND</span></div></div>
        </section>
        <section v-if="page === 'home'" class="trust-strip" aria-label="平台服务介绍"><div><Icon name="shield" /><span><strong>校园身份认证</strong><small>正式交易需完成认证</small></span></div><div><Icon name="bag" /><span><strong>平台担保交易</strong><small>支付与售后功能待接入</small></span></div><div><Icon name="location" /><span><strong>身边的好物</strong><small>同校发现，轻松交接</small></span></div><div><Icon name="leaf" /><span><strong>闲置循环利用</strong><small>让喜欢延续，让浪费减少</small></span></div></section>

        <section id="market" class="market-section">
          <div class="section-heading"><div><span class="section-kicker">{{ page === 'favorites' ? 'SAVED FOR YOU' : 'FIND YOUR NEXT FAVORITE' }}</span><h2>{{ page === 'favorites' ? '我的心动收藏' : '逛逛校园好物' }}<span class="heading-dot">.</span></h2></div><span class="section-meta">{{ page === 'favorites' ? '把喜欢留住，慢慢挑选' : '好物有故事，价格有惊喜' }}</span></div>
          <div class="category-tabs" role="group" aria-label="商品分类"><button v-for="c in categories" :key="c.id" :class="{ selected: category === c.id }" @click="category = c.id"><Icon :name="c.icon" :size="18" />{{ c.label }}</button></div>
          <div class="filters"><div class="filter-selects"><label>学校<select v-model="school" aria-label="筛选学校"><option v-for="s in schools" :key="s">{{ s }}</option></select></label><span class="divider"></span><label>成色<select v-model="condition" aria-label="筛选成色"><option>全部成色</option><option>几乎全新</option><option>九成新</option><option>八成新</option></select></label><button v-if="keyword || category !== 'all' || school !== '全部学校' || condition !== '全部成色'" class="clear-filter" @click="resetFilters">清除筛选</button></div><div class="sort-options"><span>{{ filtered.length }} 件好物</span><select v-model="sort" aria-label="排序方式"><option value="recommended">综合推荐</option><option value="newest">最新发布</option><option value="priceAsc">价格从低到高</option><option value="priceDesc">价格从高到低</option></select></div></div>
          <div v-if="filtered.length" class="product-grid">
            <article v-for="p in filtered" :key="p.id" class="product-card">
              <div class="product-image"><button class="art-button" :aria-label="'查看商品：' + p.title" @click="detail = p"><ProductArt :type="p.art" :background="p.color" /></button><span v-if="p.tag" class="product-tag">{{ p.tag }}</span><button class="favorite-button" :class="{ saved: favorites.includes(p.id) }" :aria-pressed="favorites.includes(p.id)" :aria-label="favorites.includes(p.id) ? '取消收藏' : '收藏商品'" @click="toggleFavorite(p.id)"><Icon name="heart" :size="18" /></button><span class="condition-label">{{ p.condition }}</span></div>
              <div class="product-info"><button class="product-title" @click="detail = p">{{ p.title }}</button><div class="price-row"><span class="price"><small>¥</small>{{ p.price }}</span><del v-if="p.originalPrice">¥{{ p.originalPrice }}</del><span class="school-tag">{{ p.school }}</span></div><div class="seller-row"><span class="seller"><span class="avatar">{{ p.avatar }}</span>{{ p.seller }}</span><span>{{ p.time ? p.time + ' 分钟前' : '刚刚发布' }}</span></div></div>
            </article>
          </div>
          <div v-else class="empty-state"><Icon :name="page === 'favorites' ? 'heart' : 'search'" :size="40" /><h3>{{ page === 'favorites' ? '还没有符合筛选条件的收藏' : '暂时没找到这件好物' }}</h3><p>试试其他关键词，或者换个分类看看。</p><button class="secondary-button" @click="resetFilters">查看全部</button></div>
          <div class="market-end" v-if="filtered.length"><span></span> 好物慢慢淘，喜欢刚刚好 <Icon name="leaf" :size="15" /><span></span></div>
        </section>
        <section v-if="page === 'home'" class="sell-banner"><div class="banner-icon"><Icon name="leaf" :size="35" /></div><div><h3>给闲置一个新去处，也给生活一点新空间。</h3><p>拍下你的闲置好物，让下一位同学接着喜欢。</p></div><button class="secondary-button" @click="openPublish">我也要发布 <Icon name="arrow" :size="17" /></button></section>
      </template>

      <section v-else-if="page === 'cart'" class="inner-page">
        <div class="section-heading"><div><span class="section-kicker">YOUR GOOD FINDS</span><h1>我的购物车<span class="heading-dot">.</span></h1></div><span class="section-meta">共 {{ cartProducts.length }} 件好物</span></div>
        <div class="mode-note"><Icon name="shield" :size="17" /> 当前为本地演示，商品数据和订单仅保存在本浏览器，不发起真实交易。</div>
        <template v-if="cartProducts.length"><div class="cart-list"><article v-for="item in cartProducts" :key="item.id" class="cart-item"><input type="checkbox" :checked="item.selected" :aria-label="'选择 ' + item.product.title" @change="selectItem(item.id, $event.target.checked)"><button class="cart-art" @click="detail = item.product" :aria-label="'查看 ' + item.product.title"><ProductArt :type="item.product.art" :background="item.product.color" /></button><div class="cart-item-copy"><button class="product-title" @click="detail = item.product">{{ item.product.title }}</button><p>{{ item.product.condition }} · {{ item.product.school }} · {{ item.product.seller }}</p><small>二手单件商品 · 数量 1</small></div><strong class="price"><small>¥</small>{{ item.product.price }}</strong><button class="text-button" @click="removeCart(item.id)">移除</button></article></div><div class="checkout-bar"><label><input type="checkbox" :checked="allSelected" @change="toggleAll($event.target.checked)"> 全选</label><div class="checkout-total">已选 {{ selectedItems.length }} 件 <span>合计 <strong>¥{{ money(total) }}</strong></span><button class="primary-button" :disabled="!selectedItems.length" @click="startCheckout">演示结算 <Icon name="arrow" :size="17" /></button></div></div></template>
        <div v-else class="empty-state"><Icon name="cart" :size="46" /><h3>购物车还空着</h3><p>去看看校园里有哪些值得带回家的好物。</p><button class="primary-button" @click="navigate('home')">发现好物 <Icon name="arrow" :size="17" /></button></div>
      </section>

      <section v-else class="inner-page">
        <div class="section-heading"><div><span class="section-kicker">YOUR CAMPUS CORNER</span><h1>我的校园角落<span class="heading-dot">.</span></h1></div></div>
        <div v-if="!user" class="empty-state"><Icon name="user" :size="46" /><h3>你好，未来的校园邻居</h3><p>设置演示身份，体验发布闲置和创建本地订单。</p><button class="primary-button" @click="loginOpen = true">设置演示身份</button></div>
        <template v-else><div class="profile-card"><span class="avatar profile-avatar">{{ user.name.slice(0, 1) }}</span><div><h2>{{ user.name }}</h2><p>本地演示身份 · 未进行学号认证</p></div><button class="text-button" @click="logout"><Icon name="logout" :size="17" /> 退出</button></div><div class="profile-stats"><div><strong>{{ myProducts.length }}</strong><span>我发布的</span></div><button @click="navigate('favorites')"><strong>{{ favorites.length }}</strong><span>心动收藏</span></button><div><strong>{{ orders.filter(o => o.user === user.name).length }}</strong><span>演示订单</span></div></div><div class="section-heading compact"><h2>我的演示订单</h2><span class="section-meta">无真实付款记录</span></div><div v-if="!orders.some(o => o.user === user.name)" class="empty-state small-empty"><Icon name="bag" :size="32" /><p>还没有订单，去发现下一件心动好物吧。</p></div><article v-for="order in orders.filter(o => o.user === user.name)" :key="order.no" class="order-card"><div class="order-top"><span>{{ order.no }} · {{ order.date }}</span><strong>{{ order.status }}</strong></div><div v-for="p in order.items" :key="p.id" class="order-item"><ProductArt :type="p.art" :background="p.color" /><span>{{ p.title }}</span><strong>¥{{ money(p.price) }}</strong></div><p class="order-total">共 {{ order.items.length }} 件，演示金额 <strong>¥{{ money(order.total) }}</strong></p></article></template>
      </section>
    </main>

    <footer class="footer"><div class="container footer-main"><div><button class="brand footer-brand" @click="navigate('home')"><span class="brand-mark">易<span>↗</span></span><span><strong>校易淘</strong><small>CAMPUS TRADE</small></span></button><p>让校园闲置流动起来。</p></div><div class="footer-message"><Icon name="leaf" :size="20" /><span>每一次转让，都是对美好生活的接力。</span></div><span class="footer-version">校园二手商城 · 前端演示</span></div><div class="container footer-bottom"><span>© {{ new Date().getFullYear() }} CampusTrade · 校易淘</span><span>插画与商品信息均为演示内容 · 未接入真实支付</span></div></footer>

    <el-dialog v-model="loginOpen" title="你好，校园邻居" width="420px" align-center>
      <form class="dialog-form" @submit.prevent="login"><p class="dialog-lead">先取一个喜欢的昵称，探索你的校园小集市。</p><label>演示昵称<input v-model="loginName" placeholder="例如：早八不迟到" minlength="2" maxlength="16" required autocomplete="nickname"></label><div class="mode-note">当前不是正式注册或登录，不验证手机号、密码或学号。请勿填写敏感信息。</div><label class="checkbox-label"><input v-model="agreed" type="checkbox">我已了解这是本地演示身份</label><button class="primary-button full-width" type="submit">开始逛逛 <Icon name="arrow" :size="18" /></button></form>
    </el-dialog>

    <el-dialog v-model="detailOpen" :title="detail?.title || '商品详情'" width="780px" align-center>
      <div v-if="detail" class="detail-layout"><ProductArt :type="detail.art" :background="detail.color" /><div class="detail-copy"><span class="detail-condition">{{ detail.condition }} · {{ detail.school }}</span><h2>{{ detail.title }}</h2><div class="detail-price"><span class="price"><small>¥</small>{{ detail.price }}</span><del v-if="detail.originalPrice">原价 ¥{{ detail.originalPrice }}</del></div><p>{{ detail.description }}</p><div class="detail-seller"><span class="avatar">{{ detail.avatar }}</span><strong>{{ detail.seller }}</strong><span>演示卖家</span></div><p class="detail-location"><Icon name="location" :size="16" /> {{ detail.location }}</p><div class="detail-actions"><button class="secondary-button" @click="toggleFavorite(detail.id)"><Icon name="heart" :size="17" />{{ favorites.includes(detail.id) ? '已收藏' : '收藏' }}</button><button class="primary-button" @click="addCart(detail)"><Icon name="cart" :size="18" /> 加入购物车</button></div><small class="muted">演示商品不代表真实在售，正式购买功能尚未接入。</small></div></div>
    </el-dialog>

    <el-dialog v-model="publishOpen" title="让你的闲置，遇见新主人" width="560px" align-center>
      <form class="dialog-form" @submit.prevent="submitPublish"><div class="mode-note">发布内容仅保存在本浏览器；真实上传、平台审核尚未接入。</div><label>商品名称<input v-model="publish.title" required minlength="4" maxlength="60" placeholder="给你的好物起个名字"></label><div class="form-row"><label>分类<select v-model="publish.category"><option v-for="c in categories.filter(c => c.id !== 'all')" :key="c.id" :value="c.id">{{ c.label }}</option></select></label><label>成色<select v-model="publish.condition"><option>几乎全新</option><option>九成新</option><option>八成新</option></select></label></div><div class="form-row"><label>转让价格（元）<input v-model="publish.price" type="number" min="0.01" max="99999" step="0.01" required placeholder="0.00"></label><label>交接地点<input v-model="publish.location" maxlength="40" required placeholder="如：图书馆南门"></label></div><label>商品描述<textarea v-model="publish.description" rows="4" minlength="10" maxlength="500" required placeholder="说说使用情况、配件和需要注意的小细节。"></textarea></label><button class="primary-button full-width" type="submit"><Icon name="plus" :size="18" />保存到本地演示列表</button></form>
    </el-dialog>

    <el-dialog v-model="checkoutOpen" title="确认演示订单" width="500px" align-center>
      <form class="dialog-form" @submit.prevent="submitOrder"><div class="mode-note">请使用虚构信息。不会真实支付或配送，收货信息不写入本地存储。</div><label>演示收货人<input v-model="receiver" maxlength="20" required placeholder="演示同学"></label><label>演示手机号<input v-model="contact" inputmode="numeric" maxlength="11" required placeholder="请输入虚构的 11 位手机号"></label><label>演示收货地址<input v-model="address" maxlength="100" required placeholder="如：本校西区 3 号楼"></label><div class="checkout-summary">已选 {{ selectedItems.length }} 件商品<strong>¥{{ money(total) }}</strong></div><button class="primary-button full-width" type="submit">创建演示订单 <Icon name="arrow" :size="18" /></button></form>
    </el-dialog>
  </div>
</template>